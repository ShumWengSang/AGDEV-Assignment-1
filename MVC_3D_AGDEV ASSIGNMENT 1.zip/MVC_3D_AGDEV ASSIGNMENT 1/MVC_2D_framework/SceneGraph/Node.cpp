#ifndef __NODE_H__
#include "Node.h"
#endif

CNode::CNode(void)
{
}

CNode::~CNode(void)
{
}

void CNode::Draw(void)
{
}
